FF Top-Up Admin Panel

Features:
- Admin Panel
- Confirm Order Page
- Weekly and Monthly Pack (1৳)
- Payment via Bkash and Nagad
- Contact: 01742-555689

How to Use:
1. Upload all files to your hosting (e.g., GitHub Pages or Cpanel)
2. Link 'index.html' as home page
3. Done!